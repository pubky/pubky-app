export interface DurableVolume {
	read(path: string): Uint8Array | null;
	write(path: string, bytes: Uint8Array): void;
	remove(path: string): void;
	rename(from: string, to: string): void;
	list?(prefix?: string): string[];
}
export interface SQLiteStatement {
	run(...parameters: any[]): {
		changes: number;
		lastInsertRowid: number | bigint;
	};
	get(...parameters: any[]): any;
	all(...parameters: any[]): any[];
	iterate(...parameters: any[]): IterableIterator<any>;
	/** As in better-sqlite3. The engine supplies it when an adapter has none. */
	pluck?(toggle?: boolean): SQLiteStatement;
}
export interface SQLiteCompatDatabase {
	prepare(sql: string): SQLiteStatement;
	exec(sql: string): unknown;
	pragma(sql: string): unknown;
	transaction<T extends (...args: any[]) => any>(fn: T): T;
	/** As in better-sqlite3. The engine supplies it when an adapter has none. */
	readonly inTransaction?: boolean;
	close(): void;
	backup?(destination: string): Promise<void>;
}
export interface TransportTarget {
	host: string;
	port: number;
	tls: boolean;
}
export interface SocketLike {
	on(event: string, listener: (...args: any[]) => void): any;
	write(data: Uint8Array | string, callback?: () => void): boolean;
	end(...args: any[]): any;
	destroy(error?: Error): any;
	setTimeout?(ms: number): any;
	setEncoding?(encoding: string): any;
	setKeepAlive?(enabled?: boolean): any;
	setNoDelay?(enabled?: boolean): any;
}
/** Returns an already connecting socket, emitting connect/data/error/close asynchronously. */
export type SocketFactory = ((target: TransportTarget) => SocketLike) & {
	/**
	 * Set by createRelaySocketFactory: every non-Electrum socket reaches the
	 * relay's one fixed upstream peer, so one primary is reachable through
	 * it and the runtime refuses a second (TRANSPORT_SINGLE_PEER).
	 */
	fixedUpstream?: boolean;
};
export interface PortableRuntimeOptions {
	/** Optional local development diagnostics; never persisted or sent to the relay. */
	onDiagnostic?(error: {
		phase: string;
		message: string;
		stack?: string;
	}): void;
	databaseFactory(path: string): SQLiteCompatDatabase;
	volume: DurableVolume;
	socketFactory: SocketFactory;
	/** Prepare a primary transport (for example, start Tor) before its connection deadline begins. */
	preparePrimaryDial?(host: string): Promise<void>;
	iroh?: {
		factory: IrohEndpointFactory;
		relays?: string[];
		discovery?: boolean;
	};
	electrum?: TransportTarget;
}
export interface PortableRuntime {
	/** Notify synchronously at background and foreground transitions so peer deadlines survive suspension. */
	setAppBackgrounded(backgrounded: boolean): void;
	request(input: {
		method?: string;
		path: string;
		body?: any;
		readOnly?: boolean;
	}): Promise<any>;
	close(): Promise<void>;
}
/** Durable channelize hold, read at GET /wallets/:id/api/channelize/status. */
export type ChannelizePauseStatus =
	| { paused: false }
	| { paused: true; requestId: string; since: number };
/** POST /wallets/:id/api/channelize/pause. Only the owner can release a hold. */
export interface ChannelizePauseRequest {
	paused: boolean;
	requestId: string;
}
/** Review and durable progress from /wallets/:id/api/drain. No signing data. */
export interface DrainInfo {
	revision: number;
	requestId: string;
	address: string;
	phase: 'review' | 'preparing' | 'closing' | 'sweeping' | 'pending' | 'cancelling' | 'cancelled' | 'completed';
	amountSats: number;
	feeSats: number;
	debitSats: number;
	reviewedDebitSats: number;
	feeEstimated: boolean;
	closeAmountSats: number;
	closeFeeSats: number;
	sweepAmountSats: number;
	sweepFeeSats: number;
	txids: string[];
	createdAt: number;
	expiresAt: number;
	startedAt?: number;
	error?: string;
	residualSats?: number;
}
/** POST /drain/quote; POST /drain/send and /drain/cancel use requestId only. */
export interface DrainQuoteRequest {
	requestId: string;
	address: string;
}
export declare const DEFAULT_PRIMARY: string;
export declare function createPortableRuntime(
	options: PortableRuntimeOptions
): Promise<PortableRuntime>;
export declare function createRelaySocketFactory(config: {
	electrumUrl: string;
	peerUrl: string;
	token: string;
	electrum: TransportTarget;
	WebSocket?: any;
}): SocketFactory;

/** Remaining inbound held by an immutable offline book, separate from new-request capacity. */
export interface OfflineReservation {
	state: string;
	concurrent: boolean;
	concurrentVersion?: 1 | 2;
	reservedInboundSats: number;
	unresolvedSlots: number;
}
export interface OfflineReceiveStatus {
	maxSats: number;
	available: boolean | null;
	reason: string | null;
	probedAt: number | null;
	concurrentVersion?: 1 | 2;
	reservedChannelIds: string[];
	requests: Array<{
		id: string;
		peer: string;
		amountSats: number;
		channelId?: string;
		epochId?: string;
		concurrent?: boolean;
		concurrentVersion?: 1 | 2;
		state?: string;
		snapshotSeq?: string | null;
		capabilityHold?: boolean;
		reservedInboundSats?: number;
		unresolvedSlots?: number;
		done?: boolean;
	}>;
}

export interface IrohAddress {
	endpointId: string;
	relayUrl?: string;
	directAddresses?: string[];
}
export interface IrohDiagnostics {
	endpointId: string;
	path: 'direct' | 'relay' | 'unknown';
	rttMs?: number;
}
export interface IrohStream {
	read(limit: number): Promise<Uint8Array>;
	writeAll(data: Uint8Array): Promise<void>;
	close(): void;
	closed(): Promise<void>;
	diagnostics(): IrohDiagnostics;
}
export declare class IrohTransport {
	constructor(stream: IrohStream);
	readonly transportType: 'iroh';
	readonly writableLength: number;
	on(event: string, listener: (...args: any[]) => void): this;
	write(data: Uint8Array | string, callback?: (error?: Error) => void): boolean;
	setTimeout(ms: number, callback?: () => void): this;
	setKeepAlive(enabled?: boolean, delay?: number): this;
	destroy(error?: Error): this;
	getIrohDiagnostics(): IrohDiagnostics;
}
export interface IrohEndpoint {
	address(): IrohAddress;
	connect(address: IrohAddress, timeoutMs: number): Promise<IrohTransport>;
	listen(
		onConnection: (socket: IrohTransport) => void,
		onError: (error: Error) => void
	): void;
	stopListening(): void;
	close(): Promise<void>;
}
export type IrohEndpointFactory = (options: {
	secretKey: Uint8Array;
	relays?: string[];
	discovery?: boolean;
	maxPendingInbound?: number;
	handshakeTimeoutMs?: number;
}) => Promise<IrohEndpoint>;
export declare const IROH_ALPN: string;
export interface ParsedPrimary {
	pubkey: string;
	host: string;
	port: number;
	uri: string;
	transport?:
		| {
				type: 'iroh';
				endpointId: string;
				relayUrl?: string;
				fallbackOnion?: { host: string; port: number };
		  }
		/** A Porch link: the relay's WebSocket URL with the node's route id. `host` is the relay's and `port` is 0. */
		| { type: 'ws'; url: string };
}
export declare function parsePrimaryUri(input: string): ParsedPrimary;
export declare function parsePrimaryFallback(
	primary: ParsedPrimary,
	input?: string
): ParsedPrimary | undefined;
